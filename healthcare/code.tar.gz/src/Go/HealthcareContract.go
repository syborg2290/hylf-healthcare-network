package healthcare

import (
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

type SmartContract struct {
	contractapi.Contract
}

func (s *SmartContract) InitLedger(ctx contractapi.TransactionContextInterface) error {

	var patient Patient = newPatient("P1", "Kshitij", 20, "Greater Noida", "63759927XXXX")
	patientJSON, err := json.Marshal(patient)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(patient.PatientID, patientJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	doctors := []Doctor{
		{DoctorID: "D1", DoctorName: "Vijay", DoctorContact: "985473XXXX", DoctorSpeciality: "Respiratory Physician"},
		{DoctorID: "D2", DoctorName: "Rajeev", DoctorContact: "674533XXXX", DoctorSpeciality: "Orthopedic"},
		{DoctorID: "D3", DoctorName: "Nidhi", DoctorContact: "780473XXXX", DoctorSpeciality: "Gyncecoligist"},
		{DoctorID: "D4", DoctorName: "Nikhil", DoctorContact: "9325767XXXX", DoctorSpeciality: "Cardiologist"},
	}
	ic := InsuranceCompany{
		InsuranceCompanyName:    "Good Life",
		InsuranceCompanyContact: "980890XXXX",
		InsuranceCompanyAddress: "Mumbai",
	}
	eph := Epharma{
		EPharmaName:    "Life Medicine",
		EPharmaContact: "756980XXXX",
		EPharmaAddress: "New Delhi",
	}

	for _, doctor := range doctors {
		doctorJSON, err := json.Marshal(doctor)
		if err != nil {
			return err
		}

		err = ctx.GetStub().PutState(doctor.DoctorID, doctorJSON)
		if err != nil {
			return fmt.Errorf("failed to put to world state. %v", err)
		}
	}
	icJSON, err := json.Marshal(ic)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(ic.InsuranceCompanyName, icJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	ephJSON, err := json.Marshal(eph)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(eph.EPharmaName, ephJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	var appointmentCount int64 = 0
	acJSON, err := json.Marshal(appointmentCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("AppointmentCount", acJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}

	ehrCount := 0
	ehrcJSON, err := json.Marshal(ehrCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("EHRCount", ehrcJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}

	orderCount := 0
	orderCountJSON, err := json.Marshal(orderCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("OrderCount", orderCountJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}

	return nil
}

func (s *SmartContract) BookAppointment(ctx contractapi.TransactionContextInterface, pid string, shareEHR bool, useInsurance bool) error {

	patientJSON, err := ctx.GetStub().GetState(pid)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if patientJSON == nil {
		return fmt.Errorf("the asset %s does not exist", pid)
	}
	acJSON, err := ctx.GetStub().GetState("AppointmentCount")
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if acJSON == nil {
		return fmt.Errorf("the asset %s does not exist", "AppointmentCount")
	}

	var appointmentCount int64
	var patient Patient
	err = json.Unmarshal(patientJSON, &patient)
	if err != nil {
		return err
	}
	err = json.Unmarshal(acJSON, &appointmentCount)
	if err != nil {
		return err
	}
	appointmentCount = appointmentCount + 1
	id := "A" + strconv.FormatInt(appointmentCount, 10)
	newApp := Appointment{
		AppointmentID:           id,
		AppointmentPatientID:    patient.PatientID,
		AppointmentBookingTime:  time.Now(),
		AppointmentStatus:       false,
		AppointmentShareEHR:     shareEHR,
		AppointmentUseInsurance: useInsurance,
	}
	newAppJSON, err := json.Marshal(newApp)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(id, newAppJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	acJSON, err = json.Marshal(appointmentCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("AppointmentCount", acJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	patient.addPatientAppointment(id)
	patientJSON, err = json.Marshal(patient)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(patient.PatientID, patientJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}

func (s *SmartContract) approveAppointment(ctx contractapi.TransactionContextInterface, appointmentID string, doctorID string) error {
	appointmentJSON, err := ctx.GetStub().GetState(appointmentID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if appointmentJSON == nil {
		return fmt.Errorf("the asset %s does not exist", appointmentID)
	}
	var appointment Appointment
	err = json.Unmarshal(appointmentJSON, &appointment)
	if err != nil {
		return err
	}

	appointment.setAppointmentDoctorID(doctorID)
	appointment.setAppointmentStatus(true)
	appointmentJSON, err = json.Marshal(appointment)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(appointmentID, appointmentJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}

	return nil
}

func (s *SmartContract) IssueEHR(ctx contractapi.TransactionContextInterface, appointmentID string, comments string, medicines []Medicine) error {
	appointmentJSON, err := ctx.GetStub().GetState(appointmentID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if appointmentJSON == nil {
		return fmt.Errorf("the asset %s does not exist", appointmentID)
	}
	var appointment Appointment
	err = json.Unmarshal(appointmentJSON, &appointment)
	if err != nil {
		return err
	}
	patientJSON, err := ctx.GetStub().GetState(appointment.AppointmentPatientID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if patientJSON == nil {
		return fmt.Errorf("the asset %s does not exist", appointment.AppointmentPatientID)
	}
	var patient Patient
	err = json.Unmarshal(patientJSON, &patient)
	if err != nil {
		return err
	}
	ehrcJSON, err := ctx.GetStub().GetState("EHRCount")
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if ehrcJSON == nil {
		return fmt.Errorf("the asset %s does not exist", "EHRCount")
	}
	var ehrCount int64
	err = json.Unmarshal(ehrcJSON, &ehrCount)
	if err != nil {
		return err
	}
	ehrCount = ehrCount + 1
	ehrid := "EHR" + strconv.FormatInt(ehrCount, 10)
	newEHR := EHR{
		EHRID:        ehrid,
		EHRTime:      time.Now(),
		EHRPatientID: appointment.AppointmentPatientID,
		EHRDoctorID:  appointment.AppointmentDoctorID,
		EHRComments:  comments,
		EHRMedicines: medicines,
	}
	patient.addPatientEHR(ehrid)
	newEHRJSON, err := json.Marshal(newEHR)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(ehrid, newEHRJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	ehrcJSON, err = json.Marshal(ehrCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("EHRCount", ehrcJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	patientJSON, err = json.Marshal(patient)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(patient.PatientID, patientJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}

func (s *SmartContract) placeOrder(ctx contractapi.TransactionContextInterface, ehrID string) error {
	ehrJSON, err := ctx.GetStub().GetState(ehrID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if ehrJSON == nil {
		return fmt.Errorf("the asset %s does not exist", ehrID)
	}
	var ehr EHR
	err = json.Unmarshal(ehrJSON, &ehr)
	if err != nil {
		return err
	}
	patientJSON, err := ctx.GetStub().GetState(ehr.EHRPatientID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if patientJSON == nil {
		return fmt.Errorf("the asset %s does not exist", ehr.EHRPatientID)
	}
	var patient Patient
	err = json.Unmarshal(patientJSON, &patient)
	if err != nil {
		return err
	}
	ordercJSON, err := ctx.GetStub().GetState("OrderCount")
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if ordercJSON == nil {
		return fmt.Errorf("the asset %s does not exist", "OrderCount")
	}
	var orderCount int64
	err = json.Unmarshal(ordercJSON, &orderCount)
	if err != nil {
		return err
	}
	orderCount = orderCount + 1
	orderID := "O" + strconv.FormatInt(orderCount, 10)
	newOrder := Order{
		OrderID:        orderID,
		OrderTime:      time.Now(),
		OrderMedicines: ehr.EHRMedicines,
		OrderCompleted: false,
	}
	for _, medicine := range newOrder.OrderMedicines {
		newOrder.OrderAmount = newOrder.OrderAmount + medicine.MedicineCost
	}

	newOrderJSON, err := json.Marshal(newOrder)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(orderID, newOrderJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	ordercJSON, err = json.Marshal(orderCount)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState("OrderCount", ordercJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	patient.addPatientOrder(orderID)
	patientJSON, err = json.Marshal(patient)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(patient.PatientID, patientJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}

func (s *SmartContract) completeOrder(ctx contractapi.TransactionContextInterface, orderID string) error {
	orderJSON, err := ctx.GetStub().GetState(orderID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if orderJSON == nil {
		return fmt.Errorf("the asset %s does not exist", orderID)
	}
	var order Order
	err = json.Unmarshal(orderJSON, &order)
	if err != nil {
		return err
	}
	order.setOrderCompleted(true)
	orderJSON, err = json.Marshal(order)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(orderID, orderJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}

func (s *SmartContract) raiseBill(ctx contractapi.TransactionContextInterface, appointmentID string, amount float64) error {
	appointmentJSON, err := ctx.GetStub().GetState(appointmentID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if appointmentJSON == nil {
		return fmt.Errorf("the asset %s does not exist", appointmentID)
	}
	var appointment Appointment
	err = json.Unmarshal(appointmentJSON, &appointment)
	if err != nil {
		return err
	}
	appointment.setAppointmentAmount(amount)
	appointment.setAppointmentPaid(false)
	appointmentJSON, err = json.Marshal(appointment)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(appointmentID, appointmentJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}
func (s *SmartContract) clearBill(ctx contractapi.TransactionContextInterface, appointmentID string) error {
	appointmentJSON, err := ctx.GetStub().GetState(appointmentID)
	if err != nil {
		return fmt.Errorf("failed to read from world state: %v", err)
	}
	if appointmentJSON == nil {
		return fmt.Errorf("the asset %s does not exist", appointmentID)
	}
	var appointment Appointment
	err = json.Unmarshal(appointmentJSON, &appointment)
	if err != nil {
		return err
	}
	appointment.setAppointmentPaid(true)
	appointmentJSON, err = json.Marshal(appointment)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(appointmentID, appointmentJSON)
	if err != nil {
		return fmt.Errorf("failed to put to world state. %v", err)
	}
	return nil
}
